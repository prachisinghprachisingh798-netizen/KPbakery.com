// Mobile nav toggle
  const hamburger = document.getElementById('hamburger');
  const mobilePanel = document.getElementById('mobilePanel');
  hamburger.addEventListener('click', () => {
    const open = mobilePanel.classList.toggle('open');
    hamburger.setAttribute('aria-expanded', open);
  });
  mobilePanel.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
    mobilePanel.classList.remove('open');
    hamburger.setAttribute('aria-expanded', false);
  }));

  // Menu tabs
  const tabBtns = document.querySelectorAll('.tab-btn');
  const cards = document.querySelectorAll('.menu-card');
  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      tabBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const cat = btn.dataset.cat;
      cards.forEach(c => c.classList.toggle('show', c.dataset.cat === cat));
    });
  });

  // Scroll reveal
  const revealEls = document.querySelectorAll('.reveal');
  if ('IntersectionObserver' in window) {
    const io = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('in');
          io.unobserve(entry.target);
        }
      });
    }, { threshold: 0.15 });
    revealEls.forEach(el => io.observe(el));
  } else {
    revealEls.forEach(el => el.classList.add('in'));
  }

  // Order form (front-end only — no backend wired up)
  const form = document.getElementById('orderForm');
  const formNote = document.getElementById('formNote');
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    formNote.textContent = "Thanks — your request has been noted. We'll call to confirm details.";
    formNote.style.color = 'var(--sage)';
    form.reset();
  });
